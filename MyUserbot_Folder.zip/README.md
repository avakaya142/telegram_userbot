# MyUserbot

A simple Telegram userbot based on Telethon.

## Features

- Auto-warn unknown users who message you
- `.alive` command to check bot status
- AI-ready structure (OpenAI GPT integration possible)

## Setup

1. Create a Telegram App at https://my.telegram.org to get API_ID and API_HASH.
2. Create a `.env` file based on `.env.example` and fill your credentials.
3. Install requirements:

```
pip install -r requirements.txt
```

4. Run the bot:

```
python userbot.py
```

## Deploying to Railway

- Connect your GitHub repo to Railway
- Add environment variables
- Deploy! 🚀
