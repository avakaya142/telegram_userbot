from telethon import TelegramClient, events
import logging
import os

# Logging setup
logging.basicConfig(level=logging.INFO)

# Load API ID and Hash from environment variables
API_ID = int(os.environ.get("API_ID", "YOUR_API_ID"))
API_HASH = os.environ.get("API_HASH", "YOUR_API_HASH")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "your-openai-api-key")

# Create the client
client = TelegramClient('runtime/userbot', API_ID, API_HASH)

# Approved users list
approved_users = set()

@client.on(events.NewMessage(outgoing=True, pattern=r"\.alive"))
async def alive(event):
    await event.reply("✅ I'm alive, Master!")

@client.on(events.NewMessage(incoming=True))
async def warn_unknown_users(event):
    sender = await event.get_sender()
    if sender.bot:
        return
    if sender.id in approved_users:
        return
    if event.is_private:
        await event.reply("🚫 You are not allowed to message me. Please wait until I message you first.")

# Start the client
client.start()
client.run_until_disconnected()
